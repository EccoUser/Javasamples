import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.cert.Certificate;

import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfSignatureAppearance;
import com.itextpdf.text.pdf.PdfStamper;
import com.itextpdf.text.pdf.security.BouncyCastleDigest;
import com.itextpdf.text.pdf.security.DigestAlgorithms;
import com.itextpdf.text.pdf.security.ExternalDigest;
import com.itextpdf.text.pdf.security.ExternalSignature;
import com.itextpdf.text.pdf.security.MakeSignature;
import com.itextpdf.text.pdf.security.PrivateKeySignature;

public class PDFSigning {
    public static final String KEYSTORE = "keystore.p12";
    public static final char[] PASSWORD = "Welcome@12".toCharArray();
    public static final String SRC = "C:/Users/ahmed/Downloads/input.pdf";
    public static final String DEST = "C:/Users/ahmed/Downloads/signed.pdf";

    public static void main(String[] args) throws Exception {
        KeyStore ks = KeyStore.getInstance("pkcs12");
        ks.load(new FileInputStream(KEYSTORE), PASSWORD);
        String alias = ks.aliases().nextElement();
        PrivateKey pk = (PrivateKey) ks.getKey(alias, PASSWORD);
        Certificate[] chain = ks.getCertificateChain(alias);
        PdfReader reader = new PdfReader(SRC);
        FileOutputStream fos = new FileOutputStream(DEST);
        PdfStamper stamper = PdfStamper.createSignature(reader, fos, '\0');
        PdfSignatureAppearance appearance = stamper.getSignatureAppearance();
        appearance.setReason("Approval");
        appearance.setLocation("Location");
        appearance.setVisibleSignature("sig");
        ExternalSignature es = new PrivateKeySignature(pk, DigestAlgorithms.SHA256, null);
        ExternalDigest digest = new BouncyCastleDigest();
        MakeSignature.signDetached(appearance, digest, es, chain, null, null, null, 0,
                MakeSignature.CryptoStandard.CMS);
    }
}
